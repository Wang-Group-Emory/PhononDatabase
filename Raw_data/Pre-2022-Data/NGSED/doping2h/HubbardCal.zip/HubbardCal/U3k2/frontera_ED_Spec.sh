#!/bin/sh
#SBATCH -J Nqw
#SBATCH -p development
#SBATCH -N 4              # Total # of nodes 
#SBATCH -n 32              # Total # of mpi tasks
#SBATCH -t 00:30:00
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V
cd $SLURM_SUBMIT_DIR

rm job.*
rm *.txt

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/work/00434/eijkhout/arpack/installation-3.7.0-intel/lib64
export OMP_NUM_THREADS=7
ibrun ../ED_GROUND_OBS >& mylog
wait

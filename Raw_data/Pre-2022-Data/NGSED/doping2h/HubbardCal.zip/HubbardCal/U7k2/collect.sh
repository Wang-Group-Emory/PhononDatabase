#!/bin/bash
U=8
rm jobsIDs.list
rm -r extendedHubbardRes
mkdir extendedHubbardRes
cd extendedHubbardRes
for vi in {-10..10};do
    vval=`echo $vi*0.1-4.5|bc -q`
    mkdir NqwU${U}V${vval}
    cp ../extHubbardU${U}V${vval}/*.txt ./NqwU${U}V${vval}/ 
    cp ../extHubbardU${U}V${vval}/mylog ./NqwU${U}V${vval}/
    echo "copied V=${vval}"
done

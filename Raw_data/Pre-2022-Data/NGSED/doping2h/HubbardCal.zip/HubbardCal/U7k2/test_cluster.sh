#!/bin/sh
#SBATCH -J sn3test
#SBATCH -p debug
#SBATCH --nodes=2
#SBATCH -t 00:30:00
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V

cd $SLURM_SUBMIT_DIR

rm job.*
rm *.txt
#make clean

#make migdal
#to run with 8 threads per task
export OMP_NUM_THREADS=8
srun -n 6 -c 8 ./test_cluster >& mylog
wait

#!/bin/bash
U=8
rm jobsIDs.list
for vi in {-10..10};do
    vval=`echo $vi*0.1+2|bc -q`
    cd extHubbardU${U}V${vval}
    result=`sbatch frontera_ED_Spec.sh`
    jobid=`echo $result|awk '{ print $4 }'`
    echo ${jobid} >> ../jobsIDs.list
    cd ..
done

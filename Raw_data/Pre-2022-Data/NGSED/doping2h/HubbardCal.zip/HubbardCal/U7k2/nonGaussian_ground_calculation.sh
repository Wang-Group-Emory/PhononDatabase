#!/bin/sh
#SBATCH -J FTA-Chen-Test-NGS
#SBATCH -p skx-normal
#SBATCH -N 4
#SBATCH -t 10:00:00
#SBATCH --tasks-per-node=8
#SBATCH -e job.err
#SBATCH -o job.out
cd $SLURM_SUBMIT_DIR

rm job.*
rm *.txt

export OMP_NUM_THREADS=6
ibrun ./nonGaussianEDGroundState >& mylog
wait

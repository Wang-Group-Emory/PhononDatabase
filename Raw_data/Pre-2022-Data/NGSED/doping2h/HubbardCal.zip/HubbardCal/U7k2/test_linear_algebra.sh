#!/bin/sh
#SBATCH -J sn3test
#SBATCH -p debug
#SBATCH --nodes=10
#SBATCH -t 00:30:00
#SBATCH --tasks-per-node=8
#SBATCH --cpus-per-task=8
#SBATCH --constraint=haswell
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V
cd $SLURM_SUBMIT_DIR

rm job.*
rm *.txt

export OMP_PROC_BIND=true
export OMP_PLACES=threads
export OMP_NUM_THREADS=4
srun ./testLinearAlgebra >& mylog
wait

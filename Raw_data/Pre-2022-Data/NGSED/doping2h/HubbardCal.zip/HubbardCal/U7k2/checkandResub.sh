#!/bin/bash
file=AkwMigdal.txt
minimumsize=1000
for i in {1..5};do
   for j in {1..9}; do
       cd dist0.${i}g0.$j;
       mark=0
       if [ ! -f "$file" ]; then
           mark=`expr $mark + 1`
           echo "File not found!"
       else
           actualsize=$(wc -c <"$file")
           if [ "$actualsize" -le "$minimumsize" ]; then
               echo size is $actualsize bytes in folder amp$i
               $mark=`echo 1`;
           fi
       fi
       if [ "$mark" -ne 0 ]; then
          echo "change time"
          cat > ./edison_migdal.sh<<EOF
#!/bin/sh
#SBATCH -J mgD${i}G$j
#SBATCH -p regular
#SBATCH --nodes=40
#SBATCH -t 03:30:00
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V

cd \$SLURM_SUBMIT_DIR

rm job.*
rm *.txt
export OMP_NUM_THREADS=6
srun -n 160 -c 6 ../migdal >& mylog
wait
EOF
         cat ./edison_migdal.sh
         sbatch edison_migdal.sh
       fi
       cd ..
   done
done

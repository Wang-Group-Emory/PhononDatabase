#!/bin/sh
#SBATCH -J sn3test
#SBATCH -p debug
#SBATCH --nodes=1
#SBATCH -t 00:05:00
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V

cd $SLURM_SUBMIT_DIR

rm job.*
rm *.txt
#make clean

#make migdal
#to run with 8 threads per task
export OMP_NUM_THREADS=8
srun -n 3 -c 8 ./test_hamiltonian >& mylog
wait

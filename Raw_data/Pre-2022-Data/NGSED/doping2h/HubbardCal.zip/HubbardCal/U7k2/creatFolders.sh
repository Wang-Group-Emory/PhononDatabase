#!/bin/bash
U=8
rm -r extHubbardU${U}
for vi in {-10..10};do
    vval=`echo $vi*0.1+2|bc -q`	
    mkdir extHubbardU${U}V${vval}
    cp ./*.in ./extHubbardU${U}V${vval}/
    cp ./*.config ./extHubbardU${U}V${vval}/
    cp ./frontera*.sh ./extHubbardU${U}V${vval}/
    cd extHubbardU${U}V${vval}
       echo "creating folder U${U}V${vval}"
       cat > ./model_params2.in<<EOF
Hubbard
U= ${U}   Es= -10
V= ${vval}
t= 1
EOF
       cat ./model_params2.in
       echo "params changed"
       cat > ./frontera_ED_Spec.sh<<EOF
#!/bin/sh
#SBATCH -J ExtU${U}V${vval}
#SBATCH -p normal
#SBATCH -N 10              # Total # of nodes 
#SBATCH -n 40              # Total # of mpi tasks
#SBATCH -t 01:00:00
#SBATCH -e job.err
#SBATCH -o job.out
#SBATCH -V
cd \$SLURM_SUBMIT_DIR

rm job.*
rm *.txt

export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:/work/00434/eijkhout/arpack/installation-3.7.0-intel/lib64
export OMP_NUM_THREADS=14
ibrun ../../ED_GROUND_SPEC >& mylog
wait
EOF
       cat ./frontera_ED_Spec.sh
       cd ..
done
